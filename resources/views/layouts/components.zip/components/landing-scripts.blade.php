        
        <!-- BACK TO TOP -->
        <div class="scrollToTop">
            <span class="arrow"><i class="ri-arrow-up-s-fill text-xl"></i></span>
        </div>

        <div id="responsive-overlay"> </div>
        
        <!-- POPPER JS  -->
        <script src="{{asset('build/assets/libs/@popperjs/core/umd/popper.min.js')}}"></script>

        <!-- COLOR PICKER JS -->
        <script src="{{asset('build/assets/libs/@simonwep/pickr/pickr.es5.min.js')}}"></script>

        <!-- PRELINE JS -->
        <script src="{{asset('build/assets/libs/preline/preline.js')}}"></script>

        <!-- SIMPLEBAR JS -->
        <script src="{{asset('build/assets/libs/simplebar/simplebar.min.js')}}"></script>
        
        @yield('scripts')