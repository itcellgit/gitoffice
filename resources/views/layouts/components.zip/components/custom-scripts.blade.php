        <!-- POPPER JS  -->
        <script src="{{asset('build/assets/libs/@popperjs/core/umd/popper.min.js')}}"></script>

        <!-- PRELINE JS -->
        <script src="{{asset('build/assets/libs/preline/preline.js')}}"></script>

        @yield('scripts')