            
            <footer class="mt-auto py-3 border-t dark:border-white/10 bg-white dark:bg-bgdark">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <p class="text-center">Copyright © <span id="year"></span> <a href="javascript:void(0)" class="text-primary">OFFICE ERP</a>. Designed with <span class="ri ri-heart-fill text-red-500"></span> by <a class="text-primary" href="javascript:void(0)"> KLS GIT </a> All rights reserved </p>
                </div>
            </footer>
